#!/bin/bash

echo "⚠️ Ransomware detected! Restoring backup..."

# Remove encrypted files
rm -rf /home/kali/tmp/userdata/*

# Restore files from the backup server
rsync -avz -e "ssh -o StrictHostKeyChecking=no" ahmed@10.0.2.15:/backup/agent/ /home/kali/tmp/userdata/

echo "✅ Data successfully restored!"

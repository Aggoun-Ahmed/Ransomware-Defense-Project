#!/bin/bash

# Step 1: Remove immutability
echo "Removing immutability..."
sudo chattr -R -i /agent/

# Step 2: Run rsync from agent to server
echo "Running rsync backup..."
rsync -avz ahmed@10.0.2.8:/home/kali/tmp/userdata/ /backup/agent/

# Step 3: Reapply immutability
echo "Reapplying immutability..."
sudo chattr -R +i /agent/

echo "Backup update completed!"
